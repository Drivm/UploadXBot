# Deploy to Heroku !!
- First Fork the Repo 🍴 (Or Clone It)🍣
- Click on the Deploy Button Here.
- Click on `Europe` Region in Heroku for Using DC4 Bot !!
- Fill the Environment Vars in Heroku. 🍱
- Hit Deploy Then Wait Until Finished. 🧐
- Go to Resources Tab, Turn On the Worker (Dyno) .
- Go to More at Right Top Corner and Click Logs (Behind Scenes).
- Done Bot Running . . . 🏃🏃

<p><a href="https://heroku.com/deploy?template=https://github.com/5MysterySD/Tele-LeechX/tree/master)"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku" width="200""/></a></p>

# Currently Supports Heroku ♻️
- This Doesn't Means To Abuse it by Overload and Untimately ,⛔ Ban ⛔.
- It is intend to Run For Short Purposes only.
- Use One Bot For Every Heroku Account.
- Use DC4 (Europe) Bot For Better Speed. You can Get from [`@DC4DLBot`](https://t.me/DC4DLBot) in Telegram. 

# Thanks !!
- Now Go Enjoy Your Tele-LeechX Bot 🤪🤪
